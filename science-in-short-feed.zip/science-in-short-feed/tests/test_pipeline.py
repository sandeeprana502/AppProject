"""Offline tests: no internet needed. Run with:  python -m unittest discover tests"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import fetch_news as fn  # noqa: E402

LONG = " ".join(f"Sentence number {i} has exactly seven words here." for i in range(40))

RSS = """<?xml version="1.0"?><rss version="2.0"><channel><title>t</title>
<item><title>Open story</title><link>https://example.org/a</link>
<description>&lt;p&gt;%s&lt;/p&gt;</description><pubDate>%s</pubDate></item></channel></rss>"""


class Resp:
    def __init__(self, content=b"", data=None):
        self.content, self._data = content, data

    def json(self):
        return self._data


def now_rfc():
    return fn.datetime.now(fn.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")


class Tests(unittest.TestCase):
    def test_summary_full_in_range(self):
        s, n = fn.summarise(LONG, True)
        self.assertTrue(100 <= n <= 150, n)
        self.assertTrue(s.endswith("."))

    def test_summary_snippet_short(self):
        _, n = fn.summarise(LONG, False)
        self.assertTrue(n <= 35, n)

    def test_summary_never_pads(self):
        self.assertEqual(fn.summarise("One short sentence.", True), ("One short sentence.", 3))

    def test_clean_text(self):
        self.assertEqual(fn.clean_text("<p>Hi&nbsp;<b>there</b> &amp; you</p>"), "Hi there & you")

    def test_feed_and_licence_rule(self):
        xml = (RSS % (LONG, now_rfc())).encode()
        with mock.patch.object(fn, "get", return_value=Resp(content=xml)):
            rows = fn.fetch_feed({"url": "x"})
        cutoff = fn.datetime.now(fn.timezone.utc) - fn.timedelta(days=21)
        full = fn.process({"name": "A", "category": "Space", "licence": "open", "full_summary": True}, rows, cutoff)
        snip = fn.process({"name": "B", "category": "Space", "licence": "check", "full_summary": False}, rows, cutoff)
        self.assertTrue(100 <= full[0]["words"] <= 150)
        self.assertTrue(snip[0]["words"] <= 35)
        self.assertEqual(full[0]["url"], "https://example.org/a")

    def test_usgs(self):
        data = {"features": [{"properties": {"mag": 6.1, "place": "10 km S of Town", "time": 1761955200000,
                                             "url": "https://usgs.example/e1", "title": "M 6.1 - Town", "tsunami": 1},
                              "geometry": {"coordinates": [10, 20, 35.2]}}]}
        with mock.patch.object(fn, "get", return_value=Resp(data=data)):
            rows = fn.fetch_usgs({"url": "x"})
        self.assertIn("magnitude 6.1", rows[0]["text"])
        self.assertIn("tsunami", rows[0]["text"])

    def test_apod_url(self):
        data = {"title": "T", "explanation": "E.", "date": "2026-10-17", "url": "https://i/x.jpg",
                "media_type": "image", "copyright": "A Person"}
        with mock.patch.object(fn, "get", return_value=Resp(data=data)):
            rows = fn.fetch_apod({"url": "x"})
        self.assertEqual(rows[0]["url"], "https://apod.nasa.gov/apod/ap261017.html")

    def test_europepmc_and_biorxiv(self):
        pmc = {"resultList": {"result": [{"title": "P", "abstractText": "Abs.", "id": "123", "source": "MED",
                                           "authorString": "A B, C D.", "firstPublicationDate": "2026-10-30"}]}}
        with mock.patch.object(fn, "get", return_value=Resp(data=pmc)):
            r = fn.fetch_europepmc({"url": "x"})
        self.assertEqual(r[0]["url"], "https://europepmc.org/article/MED/123")
        bio = {"collection": [{"title": "B", "abstract": "Abs.", "doi": "10.1101/2026.10.30.1", "version": "1",
                               "authors": "Doe, J.; Roe, R.", "date": "2026-10-30"}]}
        with mock.patch.object(fn, "get", return_value=Resp(data=bio)):
            r = fn.fetch_biorxiv({"url": "https://api/{from}/{to}/0/json"})
        self.assertEqual(r[0]["url"], "https://www.biorxiv.org/content/10.1101/2026.10.30.1v1")

    def test_dedupe(self):
        a = {"url": "u1", "title": "Same Title!"}
        b = {"url": "u2", "title": "same title"}
        self.assertEqual(len(fn.dedupe([a, b])), 1)

    def test_run_keeps_going_when_a_source_fails(self):
        xml = (RSS % (LONG, now_rfc())).encode()
        cfg = {"sources": [
            {"name": "Good", "category": "Space", "type": "feed", "licence": "open", "full_summary": True, "url": "g"},
            {"name": "Bad", "category": "Earth", "type": "feed", "licence": "open", "full_summary": True, "url": "b"}]}

        def fake_get(url, params=None):
            if url == "b":
                raise RuntimeError("boom")
            return Resp(content=xml)

        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            (d / "data").mkdir()
            (d / "cfg.json").write_text(json.dumps(cfg))
            with mock.patch.object(fn, "get", fake_get), \
                    mock.patch.object(fn, "OUT", d / "data" / "news.json"), \
                    mock.patch.object(fn, "LOG", d / "data" / "run_log.json"):
                self.assertEqual(fn.run(d / "cfg.json"), 0)
                news = json.loads((d / "data" / "news.json").read_text())
                log = json.loads((d / "data" / "run_log.json").read_text())
        self.assertEqual(news["count"], 1)
        self.assertEqual([s["status"] for s in log["sources"]], ["ok", "failed"])


if __name__ == "__main__":
    unittest.main()
